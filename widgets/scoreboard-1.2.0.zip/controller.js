// Texts in the controller's language: the app sets document.documentElement.lang.
const TEXT = {
  en: { home: 'Home', away: 'Away', reset: 'Reset', resetTitle: 'Set both scores to 0', show: 'Show', hide: 'Hide' },
  de: { home: 'Heim', away: 'Gast', reset: 'Zurücksetzen', resetTitle: 'Beide Spielstände auf 0 setzen', show: 'Einblenden', hide: 'Ausblenden' },
};
const T = TEXT[document.documentElement.lang.slice(0, 2)] ?? TEXT.en;

// The controller owns the score and always sends the full state, so an overlay
// that reconnects or reloads is back in sync on the next change. On load it
// picks up the score that is on air, so a restarted controller carries on
// from there instead of 0:0.
class GfxScoreboardController extends HTMLElement {
  connectedCallback() {
    this.home = 0;
    this.away = 0;
    const input = 'padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc';
    const team = (side, label) => `
      <div style="display:flex;gap:0.4em;align-items:center">
        <input class="sb-${side}-team" type="text" placeholder="${label}"
               style="flex:1;min-width:7em;${input}">
        <button class="sb-${side}-minus" title="${label} -1">−</button>
        <span class="sb-${side}-score" style="min-width:2em;text-align:center;font-weight:700">0</span>
        <button class="sb-${side}-plus" title="${label} +1">+</button>
      </div>`;
    this.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:0.5em;margin-top:0.5em">
        ${team('home', T.home)}
        ${team('away', T.away)}
        <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap">
          <button class="sb-reset" title="${T.resetTitle}">${T.reset}</button>
          <span style="display:flex;gap:0.5em;margin-left:auto">
            <button class="sb-show">${T.show}</button>
            <button class="sb-hide">${T.hide}</button>
          </span>
        </div>
      </div>
    `;
    const field = (cls) => this.querySelector(cls);
    const bump = (side, delta) => {
      this[side] = Math.max(0, this[side] + delta);
      this.sendScore();
    };
    field('.sb-home-plus').onclick = () => bump('home', 1);
    field('.sb-home-minus').onclick = () => bump('home', -1);
    field('.sb-away-plus').onclick = () => bump('away', 1);
    field('.sb-away-minus').onclick = () => bump('away', -1);
    // A team name goes on air when the field is left or Enter is pressed.
    for (const side of ['home', 'away']) {
      const name = field(`.sb-${side}-team`);
      name.onchange = () => this.sendScore();
      name.onkeydown = (e) => { if (e.key === 'Enter') name.blur(); };
    }
    field('.sb-reset').onclick = () => {
      this.home = 0;
      this.away = 0;
      this.sendScore();
    };
    field('.sb-show').onclick = () => {
      this.sendScore();
      window.gfxSend({ action: 'scoreboard:show' });
    };
    field('.sb-hide').onclick = () => window.gfxSend({ action: 'scoreboard:hide' });

    this.onState = (e) => {
      const last = e.detail.filter((cmd) => cmd.action === 'scoreboard:set').pop();
      if (!last) return;
      this.home = Math.max(0, Number(last.home) || 0);
      this.away = Math.max(0, Number(last.away) || 0);
      if (typeof last.homeTeam === 'string') field('.sb-home-team').value = last.homeTeam;
      if (typeof last.awayTeam === 'string') field('.sb-away-team').value = last.awayTeam;
      this.showScore();
    };
    document.addEventListener('gfx:state', this.onState);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:state', this.onState);
  }

  showScore() {
    this.querySelector('.sb-home-score').textContent = String(this.home);
    this.querySelector('.sb-away-score').textContent = String(this.away);
  }

  sendScore() {
    const field = (cls) => this.querySelector(cls);
    this.showScore();
    window.gfxSend({
      action: 'scoreboard:set',
      home: this.home,
      away: this.away,
      homeTeam: field('.sb-home-team').value.trim() || T.home,
      awayTeam: field('.sb-away-team').value.trim() || T.away,
    });
  }
}
customElements.define('gfx-scoreboard-controller', GfxScoreboardController);
