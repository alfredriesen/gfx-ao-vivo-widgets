// Texts in the controller's language: the app sets document.documentElement.lang.
const TEXT = {
  en: {
    message: 'Message', add: 'Add', speed: 'Speed (px/s)',
    speedTitle: 'Scroll speed in pixels per second. Leave empty for the default (120)',
    clear: 'Clear', clearTitle: 'Remove all messages', show: 'Show', hide: 'Hide',
  },
  de: {
    message: 'Meldung', add: 'Hinzufügen', speed: 'Tempo (px/s)',
    speedTitle: 'Lauftempo in Pixeln pro Sekunde. Leer lassen für den Standard (120)',
    clear: 'Leeren', clearTitle: 'Alle Meldungen entfernen', show: 'Einblenden', hide: 'Ausblenden',
  },
};
const T = TEXT[document.documentElement.lang.slice(0, 2)] ?? TEXT.en;

class GfxTickerController extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap;margin-top:0.5em">
        <input class="tk-message" type="text" placeholder="${T.message}"
               style="flex:1;min-width:12em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        <button class="tk-add">${T.add}</button>
      </div>
      <ol class="tk-queue" style="margin:0.5em 0;padding-left:1.5em;text-align:left"></ol>
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap">
        <label title="${T.speedTitle}"
               style="display:flex;gap:0.4em;align-items:center">
          ${T.speed}
          <input class="tk-speed" type="number" min="1" step="10" placeholder="120"
                 style="width:5em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        </label>
        <button class="tk-clear" title="${T.clearTitle}">${T.clear}</button>
        <span style="display:flex;gap:0.5em;margin-left:auto">
          <button class="tk-show">${T.show}</button>
          <button class="tk-hide">${T.hide}</button>
        </span>
      </div>
    `;
    const field = (cls) => this.querySelector(cls);
    const input = field('.tk-message');
    const queue = field('.tk-queue');
    const show = (message) => {
      const item = document.createElement('li');
      item.textContent = message;
      queue.append(item);
    };
    const add = () => {
      const message = input.value.trim();
      if (!message) return;
      window.gfxSend({ action: 'ticker:add', message });
      show(message);
      input.value = '';
      input.focus();
    };
    field('.tk-add').onclick = add;
    input.onkeydown = (e) => { if (e.key === 'Enter') add(); };
    field('.tk-show').onclick = () => {
      const cmd = { action: 'ticker:show' };
      const speed = Number(field('.tk-speed').value);
      if (speed > 0) cmd.speed = speed;
      window.gfxSend(cmd);
    };
    field('.tk-hide').onclick = () => window.gfxSend({ action: 'ticker:hide' });
    field('.tk-clear').onclick = () => {
      window.gfxSend({ action: 'ticker:clear' });
      queue.replaceChildren();
    };

    // Rebuild the queue from the messages that are still on air.
    this.onState = (e) => {
      queue.replaceChildren();
      for (const cmd of e.detail) {
        if (cmd.action === 'ticker:add') show(String(cmd.message));
        if (cmd.action === 'ticker:clear') queue.replaceChildren();
        if (cmd.action === 'ticker:show' && Number(cmd.speed) > 0) field('.tk-speed').value = String(cmd.speed);
      }
    };
    document.addEventListener('gfx:state', this.onState);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:state', this.onState);
  }
}
customElements.define('gfx-ticker-controller', GfxTickerController);
