# Ticker

A news-ticker bar along the bottom of the overlay that scrolls through a queue of messages. Closes #20 as a drop-in plugin.

## Install

Zip the contents of this folder and upload the ZIP from the controller's **Plugins** section:

```sh
cd widgets/ticker && zip -r ../ticker.zip .
```

Open overlays (OBS browser sources) pick up the new renderer automatically.

## Commands

| Action | Fields |
| --- | --- |
| `ticker:add` | `message` (string) |
| `ticker:clear` | none |
| `ticker:show` | `speed` (pixels per second, optional; default 120) |
| `ticker:hide` | none |

Each pass scrolls every queued message across the bar, separated by bullets, then starts over. Messages added mid-pass join on the next pass. `clear` empties the queue and stops the scroll; the bar stays up until hidden.

The queue lives in each overlay, so an overlay opened or refreshed later starts empty. The controller panel lists the messages it has sent since it was opened.
