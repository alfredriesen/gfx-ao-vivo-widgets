// Commands:
//   { action: 'ticker:add', message: string }
//   { action: 'ticker:clear' }
//   { action: 'ticker:show', speed?: number (pixels per second) }
//   { action: 'ticker:hide' }
const DEFAULT_SPEED = 120;

const STYLE = `
  :host {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 90;
    font-family: system-ui, Helvetica, Arial, sans-serif;
    line-height: 1;
    pointer-events: none;
  }
  .bar {
    display: flex;
    align-items: stretch;
    height: 2.6em;
    background: rgba(15, 15, 20, 0.92);
    border-top: 0.2em solid #e63946;
    transform: translateY(110%);
    transition: transform 0.45s cubic-bezier(0.65, 0, 0.35, 1);
  }
  .bar.visible { transform: translateY(0); }
  .viewport {
    position: relative;
    flex: 1;
    overflow: hidden;
  }
  .track {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    display: flex;
    align-items: center;
    white-space: nowrap;
    color: #fff;
    font-size: 1.4em;
    font-weight: 500;
    will-change: transform;
  }
  .item + .item::before {
    content: '\\2022';
    color: #e63946;
    margin: 0 1.2em;
  }
`;

class GfxTickerRenderer extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${STYLE}</style>
      <div class="bar"><div class="viewport"><div class="track"></div></div></div>`;
    this.bar = root.querySelector('.bar');
    this.viewport = root.querySelector('.viewport');
    this.track = root.querySelector('.track');
    this.queue = [];
    this.speed = DEFAULT_SPEED;
    this.visible = false;
    this.animation = null;
    this.onMessage = (e) => {
      const cmd = e.detail;
      if (cmd.action === 'ticker:add') this.add(cmd.message);
      if (cmd.action === 'ticker:clear') this.clear();
      if (cmd.action === 'ticker:show') this.show(cmd);
      if (cmd.action === 'ticker:hide') this.hide();
    };
    document.addEventListener('gfx:message', this.onMessage);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:message', this.onMessage);
    this.stop();
  }

  add(message) {
    const text = String(message ?? '').trim();
    if (!text) return;
    this.queue.push(text);
    // New messages join on the next pass so the current one isn't cut off.
    if (this.visible && !this.animation) this.cycle();
  }

  clear() {
    this.queue = [];
    this.stop();
    this.track.replaceChildren();
  }

  show({ speed }) {
    if (typeof speed === 'number' && speed > 0) this.speed = speed;
    this.visible = true;
    this.bar.classList.add('visible');
    if (!this.animation) this.cycle();
  }

  hide() {
    this.visible = false;
    this.bar.classList.remove('visible');
    // Let the slide-out finish before stopping the scroll.
    setTimeout(() => { if (!this.visible) this.stop(); }, 450);
  }

  stop() {
    if (this.animation) {
      this.animation.onfinish = null;
      this.animation.cancel();
      this.animation = null;
    }
  }

  // One pass scrolls every queued message across the bar, right to left.
  cycle() {
    this.stop();
    if (!this.visible || this.queue.length === 0) return;
    this.track.replaceChildren(...this.queue.map((text) => {
      const item = document.createElement('span');
      item.className = 'item';
      item.textContent = text;
      return item;
    }));
    const from = this.viewport.clientWidth;
    const to = -this.track.scrollWidth;
    const duration = ((from - to) / this.speed) * 1000;
    this.animation = this.track.animate(
      [{ transform: `translateX(${from}px)` }, { transform: `translateX(${to}px)` }],
      { duration, easing: 'linear' },
    );
    this.animation.onfinish = () => {
      this.animation = null;
      this.cycle();
    };
  }
}
customElements.define('gfx-ticker-renderer', GfxTickerRenderer);
