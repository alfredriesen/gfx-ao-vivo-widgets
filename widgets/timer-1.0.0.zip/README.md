# Countdown Timer

An on-air countdown clock in the top-right corner of the overlay. It pulses amber in the last 10 seconds and turns red at zero. Closes #19 as a drop-in plugin.

## Install

Zip the contents of this folder and upload the ZIP from the controller's **Plugins** section:

```sh
cd widgets/timer && zip -r ../timer.zip .
```

Open overlays (OBS browser sources) pick up the new renderer automatically. The clock starts hidden; press **Show** to put it on air.

## Commands

| Action | Fields |
| --- | --- |
| `timer:start` | `seconds` (number, optional). With `seconds`, sets the duration and starts from it. Without, resumes a paused clock (or restarts the last duration if it reached zero). |
| `timer:pause` | none |
| `timer:reset` | `seconds` (number, optional; sets a new duration). Stops the clock and shows the full duration. |
| `timer:show` | none |
| `timer:hide` | none |

Starting, pausing and resetting work while the clock is hidden, so you can set it up before showing it. The controller panel shows a local readout of the time left.

Each overlay keeps its own clock from the commands it receives, so an overlay opened or reloaded mid-countdown shows `00:00` until the next `start` or `reset`.
