import { Countdown, formatTime } from './clock.js';

class GfxTimerController extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap;margin-top:0.5em">
        <input class="tm-min" type="number" min="0" step="1" placeholder="Min" value="5"
               style="width:4.5em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        <span>:</span>
        <input class="tm-sec" type="number" min="0" max="59" step="1" placeholder="Sec" value="0"
               style="width:4.5em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        <button class="tm-start" title="Start from the duration entered">Start</button>
        <button class="tm-resume">Resume</button>
        <button class="tm-pause">Pause</button>
        <button class="tm-reset">Reset</button>
        <button class="tm-show">Show</button>
        <button class="tm-hide">Hide</button>
        <span class="tm-readout" title="Local preview of the on-air clock"
              style="font-variant-numeric:tabular-nums;font-weight:600;min-width:4em">00:00</span>
      </div>
    `;
    const field = (cls) => this.querySelector(cls);
    // Local mirror of the overlay clock so the operator sees the time left.
    this.countdown = new Countdown();
    const send = (cmd) => {
      this.countdown.apply(cmd);
      window.gfxSend(cmd);
      this.render();
    };
    const seconds = () =>
      Math.max(0, Number(field('.tm-min').value) || 0) * 60 + Math.max(0, Number(field('.tm-sec').value) || 0);

    field('.tm-start').onclick = () => {
      const s = seconds();
      if (s > 0) send({ action: 'timer:start', seconds: s });
    };
    field('.tm-resume').onclick = () => send({ action: 'timer:start' });
    field('.tm-pause').onclick = () => send({ action: 'timer:pause' });
    field('.tm-reset').onclick = () => send({ action: 'timer:reset', seconds: seconds() });
    field('.tm-show').onclick = () => window.gfxSend({ action: 'timer:show' });
    field('.tm-hide').onclick = () => window.gfxSend({ action: 'timer:hide' });

    this.readout = field('.tm-readout');
    this.ticker = setInterval(() => this.render(), 250);

    // Pick up the clock that is on air, and the duration it resets to.
    this.onState = (e) => {
      for (const cmd of e.detail) this.countdown.apply(cmd);
      const duration = Math.round(this.countdown.duration);
      if (duration > 0) {
        field('.tm-min').value = String(Math.floor(duration / 60));
        field('.tm-sec').value = String(duration % 60);
      }
      this.render();
    };
    document.addEventListener('gfx:state', this.onState);
  }

  disconnectedCallback() {
    clearInterval(this.ticker);
    document.removeEventListener('gfx:state', this.onState);
  }

  render() {
    this.readout.textContent = formatTime(this.countdown.remaining());
  }
}
customElements.define('gfx-timer-controller', GfxTimerController);
