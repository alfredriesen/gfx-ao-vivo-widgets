// Countdown state shared by the controller readout and the overlay renderer,
// so both apply commands the same way. Time is kept as an end timestamp
// while running so the clock doesn't drift with setInterval jitter.
export class Countdown {
  constructor() {
    this.duration = 0; // seconds the clock resets to
    this.remainingMs = 0; // when paused
    this.endsAt = null; // epoch ms when running, null when paused
  }

  get running() {
    return this.endsAt !== null;
  }

  remaining(now = Date.now()) {
    if (this.endsAt === null) return this.remainingMs;
    return Math.max(0, this.endsAt - now);
  }

  // Returns true when the command was a timer command. A command the server
  // replays to a late-joining overlay carries replayAgeMs, so it is applied as
  // of the moment it was first sent.
  apply(cmd) {
    const now = Date.now() - (Number(cmd.replayAgeMs) || 0);
    switch (cmd.action) {
      case 'timer:start': {
        const seconds = Number(cmd.seconds);
        if (Number.isFinite(seconds) && seconds > 0) {
          this.duration = seconds;
          this.remainingMs = seconds * 1000;
        } else if (this.remaining(now) === 0) {
          this.remainingMs = this.duration * 1000;
        }
        if (this.endsAt === null && this.remainingMs > 0) {
          this.endsAt = now + this.remainingMs;
        }
        return true;
      }
      case 'timer:pause':
        this.remainingMs = this.remaining(now);
        this.endsAt = null;
        return true;
      case 'timer:reset': {
        const seconds = Number(cmd.seconds);
        if (Number.isFinite(seconds) && seconds >= 0) this.duration = seconds;
        this.remainingMs = this.duration * 1000;
        this.endsAt = null;
        return true;
      }
      default:
        return false;
    }
  }
}

export function formatTime(ms) {
  const total = Math.ceil(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
