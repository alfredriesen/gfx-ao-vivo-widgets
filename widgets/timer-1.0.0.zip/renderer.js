// Commands:
//   { action: 'timer:start', seconds?: number }  set and start, or resume when omitted
//   { action: 'timer:pause' }
//   { action: 'timer:reset', seconds?: number }  stop and return to the duration
//   { action: 'timer:show' }
//   { action: 'timer:hide' }
import { Countdown, formatTime } from './clock.js';

// Seconds left at which the clock turns amber and starts pulsing.
const WARNING_SECONDS = 10;

const STYLE = `
  :host {
    position: fixed;
    top: 5vh;
    right: 4vw;
    z-index: 100;
    font-family: system-ui, Helvetica, Arial, sans-serif;
    pointer-events: none;
  }
  .clock {
    background: rgba(15, 15, 20, 0.92);
    color: #fff;
    border-bottom: 0.12em solid #e63946;
    font-size: 3em;
    font-weight: 700;
    font-variant-numeric: tabular-nums;
    padding: 0.15em 0.6em;
    opacity: 0;
    transform: translateY(-0.4em);
    transition: opacity 0.3s ease, transform 0.3s ease, color 0.3s ease, background 0.3s ease;
  }
  .clock.visible { opacity: 1; transform: none; }
  .clock.warning { color: #ffb703; animation: pulse 1s ease-in-out infinite; }
  .clock.done { background: #e63946; color: #fff; animation: none; }
  @keyframes pulse { 50% { color: #fff; } }
`;

class GfxTimerRenderer extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${STYLE}</style><div class="clock">00:00</div>`;
    this.clock = root.querySelector('.clock');
    this.countdown = new Countdown();
    this.ticker = null;
    this.onMessage = (e) => {
      const cmd = e.detail;
      if (cmd.action === 'timer:show') this.clock.classList.add('visible');
      else if (cmd.action === 'timer:hide') this.clock.classList.remove('visible');
      else if (this.countdown.apply(cmd)) this.update();
    };
    document.addEventListener('gfx:message', this.onMessage);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:message', this.onMessage);
    clearInterval(this.ticker);
  }

  update() {
    const ms = this.countdown.remaining();
    this.clock.textContent = formatTime(ms);
    const done = ms === 0 && this.countdown.duration > 0;
    this.clock.classList.toggle('done', done);
    this.clock.classList.toggle('warning', !done && ms <= WARNING_SECONDS * 1000 && this.countdown.running);
    if (this.countdown.running && ms > 0) {
      this.ticker ??= setInterval(() => this.update(), 200);
    } else {
      clearInterval(this.ticker);
      this.ticker = null;
    }
  }
}
customElements.define('gfx-timer-renderer', GfxTimerRenderer);
