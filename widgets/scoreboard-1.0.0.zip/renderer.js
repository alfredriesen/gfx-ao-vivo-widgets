// Commands:
//   { action: 'scoreboard:set', home: number, away: number, homeTeam?: string, awayTeam?: string }
//   { action: 'scoreboard:show' }
//   { action: 'scoreboard:hide' }
const STYLE = `
  :host {
    position: fixed;
    left: 4vw;
    top: 5vh;
    z-index: 100;
    font-family: system-ui, Helvetica, Arial, sans-serif;
    line-height: 1.2;
    pointer-events: none;
  }
  .board {
    display: inline-flex;
    align-items: stretch;
    font-size: 1.8em;
    font-weight: 700;
    color: #fff;
    border-radius: 0.2em;
    overflow: hidden;
    box-shadow: 0 0.15em 0.6em rgba(0, 0, 0, 0.35);
    opacity: 0;
    transform: translateY(-0.6em);
    transition: opacity 0.35s ease, transform 0.35s cubic-bezier(0.65, 0, 0.35, 1);
  }
  .board.visible { opacity: 1; transform: none; }
  .team {
    background: rgba(15, 15, 20, 0.92);
    padding: 0.3em 0.8em;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    white-space: nowrap;
    max-width: 10em;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .score {
    background: #e63946;
    padding: 0.3em 0.55em;
    min-width: 1.4em;
    text-align: center;
    font-variant-numeric: tabular-nums;
  }
  .score.home { border-right: 0.06em solid rgba(255, 255, 255, 0.35); }
  .score.bump { animation: bump 0.4s ease; }
  @keyframes bump {
    40% { background: #fff; color: #e63946; }
  }
`;

class GfxScoreboardRenderer extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${STYLE}</style>
      <div class="board">
        <div class="team home">Home</div>
        <div class="score home">0</div>
        <div class="score away">0</div>
        <div class="team away">Away</div>
      </div>`;
    this.board = root.querySelector('.board');
    this.homeTeamEl = root.querySelector('.team.home');
    this.awayTeamEl = root.querySelector('.team.away');
    this.homeScoreEl = root.querySelector('.score.home');
    this.awayScoreEl = root.querySelector('.score.away');
    this.onMessage = (e) => {
      const cmd = e.detail;
      if (cmd.action === 'scoreboard:set') this.set(cmd);
      if (cmd.action === 'scoreboard:show') this.board.classList.add('visible');
      if (cmd.action === 'scoreboard:hide') this.board.classList.remove('visible');
    };
    document.addEventListener('gfx:message', this.onMessage);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:message', this.onMessage);
  }

  set({ home, away, homeTeam, awayTeam }) {
    this.setScore(this.homeScoreEl, home);
    this.setScore(this.awayScoreEl, away);
    if (typeof homeTeam === 'string') this.homeTeamEl.textContent = homeTeam;
    if (typeof awayTeam === 'string') this.awayTeamEl.textContent = awayTeam;
  }

  setScore(el, value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return;
    const text = String(n);
    if (el.textContent === text) return;
    el.textContent = text;
    // Restart the flash animation on every change.
    el.classList.remove('bump');
    void el.offsetWidth;
    el.classList.add('bump');
  }
}
customElements.define('gfx-scoreboard-renderer', GfxScoreboardRenderer);
