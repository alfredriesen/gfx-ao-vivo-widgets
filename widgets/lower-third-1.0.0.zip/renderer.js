// Commands:
//   { action: 'lower-third:show', name: string, title?: string, duration?: number (seconds) }
//   { action: 'lower-third:hide' }
const STYLE = `
  :host {
    position: fixed;
    left: 4vw;
    bottom: 8vh;
    z-index: 100;
    font-family: system-ui, Helvetica, Arial, sans-serif;
    line-height: 1.3;
    text-align: left;
    pointer-events: none;
  }
  .card {
    display: inline-flex;
    flex-direction: column;
    overflow: hidden;
    border-left: 0.35em solid #e63946;
    clip-path: inset(0 100% 0 0);
    transition: clip-path 0.45s cubic-bezier(0.65, 0, 0.35, 1);
  }
  .card.visible { clip-path: inset(0 0 0 0); }
  .name {
    background: rgba(15, 15, 20, 0.92);
    color: #fff;
    font-size: 2.2em;
    font-weight: 700;
    padding: 0.2em 0.8em 0.1em;
    white-space: nowrap;
  }
  .title {
    background: #e63946;
    color: #fff;
    font-size: 1.2em;
    font-weight: 500;
    letter-spacing: 0.04em;
    text-transform: uppercase;
    padding: 0.25em 1.5em 0.25em 1.45em;
    white-space: nowrap;
  }
  .title:empty { display: none; }
`;

class GfxLowerThirdRenderer extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${STYLE}</style>
      <div class="card"><div class="name"></div><div class="title"></div></div>`;
    this.card = root.querySelector('.card');
    this.nameEl = root.querySelector('.name');
    this.titleEl = root.querySelector('.title');
    this.hideTimer = null;
    this.onMessage = (e) => {
      const cmd = e.detail;
      if (cmd.action === 'lower-third:show') this.show(cmd);
      if (cmd.action === 'lower-third:hide') this.hide();
    };
    document.addEventListener('gfx:message', this.onMessage);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:message', this.onMessage);
    clearTimeout(this.hideTimer);
  }

  // replayAgeMs is set when the server replays this command to an overlay that
  // connected after it was sent.
  show({ name, title, duration, replayAgeMs = 0 }) {
    clearTimeout(this.hideTimer);
    this.nameEl.textContent = String(name ?? '');
    this.titleEl.textContent = String(title ?? '');
    this.card.classList.add('visible');
    if (typeof duration === 'number' && duration > 0) {
      this.hideTimer = setTimeout(() => this.hide(), duration * 1000 - replayAgeMs);
    }
  }

  hide() {
    clearTimeout(this.hideTimer);
    this.card.classList.remove('visible');
  }
}
customElements.define('gfx-lower-third-renderer', GfxLowerThirdRenderer);
