# Scoreboard

A home/away score bug in the top-left of the overlay, updated live from the controller. Closes #18 as a drop-in plugin.

## Install

Zip the contents of this folder and upload the ZIP from the controller's **Plugins** section:

```sh
cd widgets/scoreboard && zip -r ../scoreboard.zip .
```

Open overlays (OBS browser sources) pick up the new renderer automatically.

## Controller

Type the team names (a name goes on air when you leave the field or press Enter), use **+** / **−** to change each score (every click updates the overlay), and **Show** / **Hide** to bring the board on and off screen. **Reset** sets both scores to 0.

## Commands

| Action | Fields |
| --- | --- |
| `scoreboard:set` | `home` (number), `away` (number), `homeTeam` (string, optional), `awayTeam` (string, optional) |
| `scoreboard:show` | none |
| `scoreboard:hide` | none |

`set` works while the board is hidden, so you can prepare the score before showing it. A changed score briefly flashes.
