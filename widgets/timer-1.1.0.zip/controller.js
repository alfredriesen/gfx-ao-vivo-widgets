import { Countdown, formatTime } from './clock.js';

class GfxTimerController extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap;margin-top:0.5em">
        <input class="tm-min" type="number" min="0" step="1" placeholder="Min" value="5"
               style="width:4.5em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        <span>:</span>
        <input class="tm-sec" type="number" min="0" max="59" step="1" placeholder="Sec" value="0"
               style="width:4.5em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        <span class="tm-readout" title="Local preview of the on-air clock"
              style="font-variant-numeric:tabular-nums;font-weight:600;min-width:4em">00:00</span>
      </div>
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap;margin-top:0.5em">
        <button class="tm-toggle" style="min-width:6.5em">Start</button>
        <button class="tm-reset" title="Stop and set the clock back to the duration entered">Reset</button>
        <span style="display:flex;gap:0.5em;margin-left:auto">
          <button class="tm-show">Show</button>
          <button class="tm-hide">Hide</button>
        </span>
      </div>
    `;
    const field = (cls) => this.querySelector(cls);
    // Local mirror of the overlay clock so the operator sees the time left.
    this.countdown = new Countdown();
    const send = (cmd) => {
      this.countdown.apply(cmd);
      window.gfxSend(cmd);
      this.render();
    };
    const seconds = () =>
      Math.max(0, Number(field('.tm-min').value) || 0) * 60 + Math.max(0, Number(field('.tm-sec').value) || 0);

    this.seconds = seconds;

    // One button: Pause while the clock runs, Resume while it is paused part
    // way through, otherwise Start from the duration entered.
    field('.tm-toggle').onclick = () => {
      const mode = this.mode();
      if (mode === 'pause') send({ action: 'timer:pause' });
      else if (mode === 'resume') send({ action: 'timer:start' });
      else {
        const s = seconds();
        if (s > 0) send({ action: 'timer:start', seconds: s });
      }
    };
    field('.tm-reset').onclick = () => send({ action: 'timer:reset', seconds: seconds() });
    field('.tm-show').onclick = () => window.gfxSend({ action: 'timer:show' });
    field('.tm-hide').onclick = () => window.gfxSend({ action: 'timer:hide' });

    this.readout = field('.tm-readout');
    this.toggle = field('.tm-toggle');
    this.ticker = setInterval(() => this.render(), 250);

    // Pick up the clock that is on air, and the duration it resets to.
    this.onState = (e) => {
      for (const cmd of e.detail) this.countdown.apply(cmd);
      const duration = Math.round(this.countdown.duration);
      if (duration > 0) {
        field('.tm-min').value = String(Math.floor(duration / 60));
        field('.tm-sec').value = String(duration % 60);
      }
      this.render();
    };
    document.addEventListener('gfx:state', this.onState);
  }

  disconnectedCallback() {
    clearInterval(this.ticker);
    document.removeEventListener('gfx:state', this.onState);
  }

  // What the toggle does now. Editing the duration while paused turns
  // Resume back into Start, so the new duration is used.
  mode() {
    const c = this.countdown;
    if (c.running) return 'pause';
    const left = c.remaining();
    if (left > 0 && left < c.duration * 1000 && this.seconds() === c.duration) return 'resume';
    return 'start';
  }

  render() {
    this.readout.textContent = formatTime(this.countdown.remaining());
    const mode = this.mode();
    this.toggle.textContent = { pause: 'Pause', resume: 'Resume', start: 'Start' }[mode];
    this.toggle.title = {
      pause: 'Pause the clock',
      resume: 'Carry on from where the clock was paused',
      start: 'Start from the duration entered',
    }[mode];
  }
}
customElements.define('gfx-timer-controller', GfxTimerController);
