# Lower Third

A name/title banner that wipes in from the left of the overlay. Closes #17 as a drop-in plugin.

## Install

Zip the contents of this folder and upload the ZIP from the controller's **Plugins** section:

```sh
cd widgets/lower-third && zip -r ../lower-third.zip .
```

Open overlays (OBS browser sources) pick up the new renderer automatically.

In the panel, enter a name and title and press **Show**. Put a number of seconds into **Auto-hide after (s)** to take it off screen on its own; leave it empty to keep it up until you press **Hide**.

## Commands

| Action | Fields |
| --- | --- |
| `lower-third:show` | `name` (string), `title` (string, optional), `duration` (seconds, optional; omit to stay up until hidden) |
| `lower-third:hide` | none |

Sending `show` while the banner is up replaces the text and restarts the duration.
