class GfxLowerThirdController extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap;margin-top:0.5em">
        <input class="lt-name" type="text" placeholder="Name"
               style="flex:1;min-width:8em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        <input class="lt-title" type="text" placeholder="Title"
               style="flex:1;min-width:8em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
      </div>
      <div style="display:flex;gap:0.5em;align-items:center;flex-wrap:wrap;margin-top:0.5em">
        <label title="Leave empty to keep it on screen until you press Hide"
               style="display:flex;gap:0.4em;align-items:center">
          Auto-hide after (s)
          <input class="lt-duration" type="number" min="0" step="1" placeholder="off"
                 style="width:5em;padding:0.4em 0.6em;border-radius:6px;border:1px solid #ccc">
        </label>
        <span style="display:flex;gap:0.5em;margin-left:auto">
          <button class="lt-show">Show</button>
          <button class="lt-hide">Hide</button>
        </span>
      </div>
    `;
    const field = (cls) => this.querySelector(cls);
    field('.lt-show').onclick = () => {
      const name = field('.lt-name').value.trim();
      const title = field('.lt-title').value.trim();
      if (!name) return;
      const cmd = { action: 'lower-third:show', name, title };
      const duration = Number(field('.lt-duration').value);
      if (duration > 0) cmd.duration = duration;
      window.gfxSend(cmd);
    };
    field('.lt-hide').onclick = () => {
      window.gfxSend({ action: 'lower-third:hide' });
    };

    // Fill in the lower third that was shown last, so it can be shown again.
    this.onState = (e) => {
      const last = e.detail.filter((cmd) => cmd.action === 'lower-third:show').pop();
      if (!last) return;
      field('.lt-name').value = String(last.name ?? '');
      field('.lt-title').value = String(last.title ?? '');
      if (Number(last.duration) > 0) field('.lt-duration').value = String(last.duration);
    };
    document.addEventListener('gfx:state', this.onState);
  }

  disconnectedCallback() {
    document.removeEventListener('gfx:state', this.onState);
  }
}
customElements.define('gfx-lower-third-controller', GfxLowerThirdController);
